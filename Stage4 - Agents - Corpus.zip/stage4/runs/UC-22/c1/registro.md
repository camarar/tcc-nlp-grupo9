# Registro de execução — UC-22 / c1

- **Data (UTC):** 2026-08-13T19:09:54+00:00
- **Claude Code CLI:** `2.1.197 (Claude Code)`
- **Modelo do gerador:** `claude-sonnet-5` (pinado via --model)
- **Condição:** c1
- **k:** 1
- **Material entregue ao gerador:** enunciado.md + tests_visiveis/
- **Higiene:** diretório temporário limpo por geração, auditado contra ['_ref', 'gabarito.md', 'lacunas.json', 'tests_cegos'].
